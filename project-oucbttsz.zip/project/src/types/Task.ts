export interface Task {
  id: number;
  text: string;
  completed: boolean;
  deadline: Date | null;
}

export type SortType = 'deadline' | 'alphabetical';