<script setup lang="ts">
import { ref } from 'vue';

const emit = defineEmits<{
  (e: 'add-task', text: string, deadline: Date | null): void;
}>();

const text = ref('');
const deadline = ref('');
const error = ref('');

const addTask = () => {
  if (!text.value.trim()) {
    error.value = 'Task text is required';
    return;
  }
  
  if (text.value.length > 255) {
    error.value = 'Task text cannot exceed 255 characters';
    return;
  }

  emit('add-task', text.value, deadline.value ? new Date(deadline.value) : null);
  text.value = '';
  deadline.value = '';
  error.value = '';
};
</script>

<template>
  <form @submit.prevent="addTask" class="task-form">
    <div class="form-group">
      <input
        v-model="text"
        type="text"
        placeholder="Enter task..."
        maxlength="255"
        class="task-input"
      />
      <input
        v-model="deadline"
        type="datetime-local"
        class="deadline-input"
      />
      <button type="submit" class="add-button">Add Task</button>
    </div>
    <p v-if="error" class="error">{{ error }}</p>
  </form>
</template>

<style scoped>
.task-form {
  margin-bottom: 2rem;
}

.form-group {
  display: flex;
  gap: 1rem;
}

.task-input, .deadline-input {
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.task-input {
  flex: 1;
}

.add-button {
  background-color: #42b883;
  color: white;
}

.error {
  color: #ff4444;
  margin-top: 0.5rem;
  font-size: 0.9rem;
}
</style>