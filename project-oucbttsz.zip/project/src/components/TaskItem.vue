<script setup lang="ts">
import { ref } from 'vue';
import type { Task } from '../types/Task';

const props = defineProps<{
  task: Task;
}>();

const emit = defineEmits<{
  (e: 'update', id: number, text: string): void;
  (e: 'delete', id: number): void;
  (e: 'toggle', id: number): void;
}>();

const isEditing = ref(false);
const editedText = ref(props.task.text);

const startEditing = () => {
  isEditing.value = true;
  editedText.value = props.task.text;
};

const saveEdit = () => {
  if (editedText.value.trim() && editedText.value.length <= 255) {
    emit('update', props.task.id, editedText.value);
    isEditing.value = false;
  }
};

const formatDate = (date: Date | null) => {
  if (!date) return '';
  return new Date(date).toLocaleString();
};
</script>

<template>
  <div class="task-item" :class="{ completed: task.completed }">
    <div v-if="!isEditing" class="task-content">
      <input
        type="checkbox"
        :checked="task.completed"
        @change="emit('toggle', task.id)"
      />
      <span class="task-text">{{ task.text }}</span>
      <span v-if="task.deadline" class="deadline">
        {{ formatDate(task.deadline) }}
      </span>
      <div class="task-actions">
        <button @click="startEditing" class="edit-button">Edit</button>
        <button @click="emit('delete', task.id)" class="delete-button">Delete</button>
      </div>
    </div>
    <div v-else class="edit-mode">
      <input
        v-model="editedText"
        type="text"
        @keyup.enter="saveEdit"
        @keyup.esc="isEditing = false"
        maxlength="255"
      />
      <button @click="saveEdit" class="save-button">Save</button>
      <button @click="isEditing = false" class="cancel-button">Cancel</button>
    </div>
  </div>
</template>

<style scoped>
.task-item {
  padding: 1rem;
  border: 1px solid #ddd;
  margin-bottom: 0.5rem;
  border-radius: 4px;
  background-color: white;
}

.task-content {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.task-text {
  flex: 1;
}

.completed .task-text {
  text-decoration: line-through;
  color: #888;
}

.deadline {
  font-size: 0.9rem;
  color: #666;
}

.task-actions {
  display: flex;
  gap: 0.5rem;
}

.edit-button, .delete-button, .save-button, .cancel-button {
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
}

.edit-button {
  background-color: #4CAF50;
}

.delete-button {
  background-color: #f44336;
}

.edit-mode {
  display: flex;
  gap: 0.5rem;
}

.edit-mode input {
  flex: 1;
  padding: 0.25rem;
  border: 1px solid #ddd;
  border-radius: 4px;
}
</style>