<script setup lang="ts">
import { computed } from 'vue';
import type { Task, SortType } from '../types/Task';
import TaskItem from './TaskItem.vue';

const props = defineProps<{
  tasks: Task[];
  sortType: SortType;
}>();

const emit = defineEmits<{
  (e: 'update', id: number, text: string): void;
  (e: 'delete', id: number): void;
  (e: 'toggle', id: number): void;
}>();

const sortedTasks = computed(() => {
  return [...props.tasks].sort((a, b) => {
    if (props.sortType === 'deadline') {
      if (!a.deadline) return 1;
      if (!b.deadline) return -1;
      return a.deadline.getTime() - b.deadline.getTime();
    } else {
      return a.text.localeCompare(b.text);
    }
  });
});
</script>

<template>
  <div class="task-list">
    <TaskItem
      v-for="task in sortedTasks"
      :key="task.id"
      :task="task"
      @update="(id, text) => emit('update', id, text)"
      @delete="(id) => emit('delete', id)"
      @toggle="(id) => emit('toggle', id)"
    />
  </div>
</template>

<style scoped>
.task-list {
  margin-top: 1rem;
}
</style>