<script setup lang="ts">
import { ref, onMounted, watch } from 'vue';
import type { Task, SortType } from './types/Task';
import TaskForm from './components/TaskForm.vue';
import TaskList from './components/TaskList.vue';

const tasks = ref<Task[]>([]);
const sortType = ref<SortType>('deadline');
const MAX_TASKS = 100;

// Load tasks from localStorage
onMounted(() => {
  const savedTasks = localStorage.getItem('tasks');
  if (savedTasks) {
    tasks.value = JSON.parse(savedTasks, (key, value) => {
      if (key === 'deadline' && value) {
        return new Date(value);
      }
      return value;
    });
  }
});

// Save tasks to localStorage when they change
watch(tasks, (newTasks) => {
  localStorage.setItem('tasks', JSON.stringify(newTasks));
}, { deep: true });

const addTask = (text: string, deadline: Date | null) => {
  if (tasks.value.length >= MAX_TASKS) {
    alert('Maximum number of tasks (100) reached');
    return;
  }

  tasks.value.push({
    id: Date.now(),
    text,
    completed: false,
    deadline
  });
};

const updateTask = (id: number, text: string) => {
  const task = tasks.value.find(t => t.id === id);
  if (task) {
    task.text = text;
  }
};

const deleteTask = (id: number) => {
  tasks.value = tasks.value.filter(t => t.id !== id);
};

const toggleTask = (id: number) => {
  const task = tasks.value.find(t => t.id === id);
  if (task) {
    task.completed = !task.completed;
  }
};

const toggleSort = () => {
  sortType.value = sortType.value === 'deadline' ? 'alphabetical' : 'deadline';
};
</script>

<template>
  <div class="container">
    <h1>Todo List</h1>
    
    <div class="controls">
      <TaskForm @add-task="addTask" />
      <button @click="toggleSort" class="sort-button">
        Sort by: {{ sortType === 'deadline' ? 'Deadline' : 'Alphabetical' }}
      </button>
    </div>

    <TaskList
      :tasks="tasks"
      :sort-type="sortType"
      @update="updateTask"
      @delete="deleteTask"
      @toggle="toggleTask"
    />
  </div>
</template>

<style>
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
}

h1 {
  color: #42b883;
  text-align: center;
  margin-bottom: 2rem;
}

.controls {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1rem;
}

.sort-button {
  align-self: flex-end;
  background-color: #42b883;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
}

@media (prefers-color-scheme: dark) {
  body {
    background-color: #1a1a1a;
    color: #fff;
  }

  .task-item {
    background-color: #2a2a2a;
    border-color: #333;
  }

  input[type="text"],
  input[type="datetime-local"] {
    background-color: #2a2a2a;
    color: #fff;
    border-color: #444;
  }
}
</style>